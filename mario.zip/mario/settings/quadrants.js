FullScreenMario.FullScreenMario.settings.quadrants = {
    "numRows": 5,
    "numCols": 6,
    "tolerance": FullScreenMario.FullScreenMario.unitsize / 2,
    "groupNames": ["Solid", "Character", "Scenery", "Text"],
    "keyGroupName": "groupType"
};
